package com.techelevator.tenmo.services;

import com.techelevator.tenmo.model.AuthenticatedUser;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import com.techelevator.tenmo.model.User;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class AccountService {

    private final String baseUrl;
    private final RestTemplate restTemplate = new RestTemplate();

    public AccountService(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public BigDecimal getBalance(AuthenticatedUser currentUser) {
        // Set up the authorization header with the user token
        String token = currentUser.getToken();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        // Make the GET request to /account/balance
        return restTemplate.exchange(
                baseUrl + "/account/balance",
                HttpMethod.GET,
                entity,
                BigDecimal.class
        ).getBody();
    }

    public List<User> getUsers(String token) {
        // Set up headers with authentication token
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        // Make GET request to /users endpoint
        User[] users = restTemplate.exchange(baseUrl + "/users", HttpMethod.GET, entity, User[].class).getBody();
        return Arrays.asList(users);
    }

    public int getUserIdByUsername(String username, String token) {
        // Set up headers with authorization token
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        // Make GET request to /users/{username}/id endpoint
        String url = baseUrl + "/users/" + username + "/id";
        return restTemplate.exchange(url, HttpMethod.GET, entity, Integer.class).getBody();
    }

    public int findAccountIdByUsername(String username, String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        String url = baseUrl + "/account/" + username + "/id";  // Endpoint to retrieve account_id by username
        ResponseEntity<Integer> response = restTemplate.exchange(url, HttpMethod.GET, entity, Integer.class);

        return response.getBody();
    }

    // New method to get balance by account ID
    public BigDecimal getBalanceByAccountId(int accountId, String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        HttpEntity<Void> entity = new HttpEntity<>(headers);

        ResponseEntity<BigDecimal> response = restTemplate.exchange(baseUrl + "/account/" + accountId + "/balance", HttpMethod.GET, entity, BigDecimal.class);
        return response.getBody();
    }

    // New method to update the balance of an account by its ID
    public boolean updateBalance(int accountId, BigDecimal newBalance, String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(token);
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> body = new HashMap<>();
        body.put("newBalance", newBalance);

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);
        try {
            restTemplate.put(baseUrl + "/account/" + accountId + "/balance", entity);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}