package com.techelevator.tenmo;


import com.techelevator.tenmo.model.AuthenticatedUser;
import com.techelevator.tenmo.model.Transfer;
import com.techelevator.tenmo.model.User;
import com.techelevator.tenmo.model.UserCredentials;
import com.techelevator.tenmo.services.AccountService;
import com.techelevator.tenmo.services.AuthenticationService;
import com.techelevator.tenmo.services.ConsoleService;
import com.techelevator.tenmo.services.TransferService;


import java.math.BigDecimal;
import java.util.List;

public class App {

    private static final String API_BASE_URL = "http://localhost:8080/";

    private final ConsoleService consoleService = new ConsoleService();
    private final AuthenticationService authenticationService = new AuthenticationService(API_BASE_URL);
    private final AccountService accountService = new AccountService(API_BASE_URL);
    private final TransferService transferService = new TransferService(API_BASE_URL);

    private AuthenticatedUser currentUser;


    public static void main(String[] args) {
        App app = new App();
        app.run();
    }

    private void run() {
        consoleService.printGreeting();
        loginMenu();
        if (currentUser != null) {
            mainMenu();
        }
    }
    private void loginMenu() {
        int menuSelection = -1;
        while (menuSelection != 0 && currentUser == null) {
            consoleService.printLoginMenu();
            menuSelection = consoleService.promptForMenuSelection("Please choose an option: ");
            if (menuSelection == 1) {
                handleRegister();
            } else if (menuSelection == 2) {
                handleLogin();
            } else if (menuSelection != 0) {
                System.out.println("Invalid Selection");
                consoleService.pause();
            }
        }
    }

    private void handleRegister() {
        System.out.println("Please register a new user account");
        UserCredentials credentials = consoleService.promptForCredentials();
        if (authenticationService.register(credentials)) {
            System.out.println("Registration successful. You can now login.");
        } else {
            consoleService.printErrorMessage();
        }
    }

    private void handleLogin() {
        UserCredentials credentials = consoleService.promptForCredentials();
        currentUser = authenticationService.login(credentials);
        if (currentUser == null) {
            consoleService.printErrorMessage();
        }
    }

    private void mainMenu() {
        int menuSelection = -1;
        while (menuSelection != 0) {
            consoleService.printMainMenu();
            menuSelection = consoleService.promptForMenuSelection("Please choose an option: ");
            if (menuSelection == 1) {
                viewCurrentBalance();
            } else if (menuSelection == 2) {
                viewTransferHistory();
            } else if (menuSelection == 3) {
                viewPendingRequests();
            } else if (menuSelection == 4) {
                sendBucks();
            } else if (menuSelection == 5) {
                requestBucks();
            } else if (menuSelection == 0) {
                continue;
            } else {
                System.out.println("Invalid Selection");
            }
            consoleService.pause();
        }
    }

	private void viewCurrentBalance() {
        if (currentUser != null) {
            try {
                BigDecimal balance = accountService.getBalance(currentUser);
                System.out.println("Your current balance is: " + balance + " TE bucks");
            } catch (Exception e) {
                System.out.println("Error retrieving balance. Please try again.");
                e.printStackTrace();
            }
        } else {
            System.out.println("You need to be logged in to view your balance.");
        }
	}

	private void viewTransferHistory() {
        if (currentUser != null) {
            try {
                int userAccountId = accountService.findAccountIdByUsername(currentUser.getUser().getUsername(), currentUser.getToken());

                List<Transfer> transfers = transferService.getTransferHistory(currentUser.getToken());
                System.out.println("Your Transfer History:");

                boolean hasTransfers = false;
                for (Transfer transfer : transfers) {
                    if (transfer.getAccountFrom() == userAccountId || transfer.getAccountTo() == userAccountId) {
                        System.out.println("Transfer ID: " + transfer.getTransferId() +
                                ", From: " + transfer.getAccountFrom() +
                                ", To: " + transfer.getAccountTo() +
                                ", Amount: " + transfer.getAmount() +
                                ", Status: " + transfer.getTransferStatusId() +
                                ", Type: " + transfer.getTransferTypeId());
                        hasTransfers = true;
                    }
                }

                if (!hasTransfers) {
                    System.out.println("No transfer history available.");
                }
            } catch (Exception e) {
                System.out.println("Error retrieving transfer history. Please try again.");
                e.printStackTrace();
                return;
            }
            int transferId = consoleService.promptForInt("Enter the transfer ID for history: ");
            try {
                Transfer transfer = transferService.getTransferById(currentUser.getToken(), transferId);
                System.out.println("Transfer Details:");
                System.out.println("Transfer ID: " + transfer.getTransferId());
                System.out.println("From Account ID: " + transfer.getAccountFrom());
                System.out.println("To Account ID: " + transfer.getAccountTo());
                System.out.println("Amount: " + transfer.getAmount());
                System.out.println("Status ID: " + transfer.getTransferStatusId());
                System.out.println("Type ID: " + transfer.getTransferTypeId());
            } catch (Exception e) {
                System.out.println("Error retrieving transfer details. Please check the transfer ID and try again.");
            }
        } else {
            System.out.println("You need to be logged in to view transfer details.");
        }
		
	}

	private void viewPendingRequests() {
        if (currentUser != null) {
            try {
                List<Transfer> pendingTransfers = transferService.getPendingTransfers(currentUser.getToken());
                System.out.println("Your Pending Transfers:");
                if (pendingTransfers.isEmpty()) {
                    System.out.println("No pending transfers were found.");
                } else {
                    for (Transfer transfer : pendingTransfers) {
                        System.out.println("\nTransfer ID: " + transfer.getTransferId());
                        System.out.println("From Account ID: " + transfer.getAccountFrom());
                        System.out.println("To Account ID: " + transfer.getAccountTo());
                        System.out.println("Amount: " + transfer.getAmount());
                    }
                }

                if (!pendingTransfers.isEmpty()) {
                    int transferId = consoleService.promptForInt("\nEnter the transfer ID to approve or reject (0 to cancel): ");
                    if (transferId == 0) {
                        return; // Exit if user enters 0
                    }

                    Transfer transfer = transferService.getTransferById(currentUser.getToken(), transferId);

                    int userAccountId = accountService.findAccountIdByUsername(currentUser.getUser().getUsername(), currentUser.getToken());
                    if (transfer.getAccountTo() != userAccountId) {
                        System.out.println("You can only approve or reject requests directed to your account.");
                        return;
                    }

                    String choice = consoleService.promptForString("Approve (A) or Reject (R) the transfer? ");
                    if (choice.equalsIgnoreCase("A")) {
                        // Get requester account balance (the person approving is sending the money)
                        BigDecimal requesterBalance = accountService.getBalance(currentUser);

                        if (requesterBalance.compareTo(transfer.getAmount()) >= 0) {
                            // Update the requester's (sender's) balance
                            int requesterAccountId = transfer.getAccountTo(); // The requestor's account (recipient in the transfer)
                            boolean debitSuccess = accountService.updateBalance(requesterAccountId, requesterBalance.subtract(transfer.getAmount()), currentUser.getToken());
                            if (!debitSuccess) {
                                System.out.println("Failed to debit requester's account. Please try again.");
                                return;
                            }

                            // Update the recipient's (requestee's) balance
                            int recipientAccountId = transfer.getAccountFrom(); // The recipient (sender in the transfer)
                            BigDecimal recipientBalance = accountService.getBalanceByAccountId(recipientAccountId, currentUser.getToken());
                            boolean creditSuccess = accountService.updateBalance(recipientAccountId, recipientBalance.add(transfer.getAmount()), currentUser.getToken());
                            if (!creditSuccess) {
                                System.out.println("Failed to credit recipient's account. Please try again.");
                                // Optionally, refund requester here to maintain consistency
                                return;
                            }

                            transfer.setTransferStatusId(Transfer.TRANSFER_STATUS_APPROVED);
                            boolean updateStatusSuccess = transferService.updateTransferStatus(currentUser.getToken(), transfer);
                            if (updateStatusSuccess) {
                                System.out.println("Transfer approved successfully!");
                            } else {
                                System.out.println("Transfer approved, but failed to update the transfer status.");
                            }
                        } else {
                            System.out.println("Insufficient funds to approve this transfer.");
                        }
                    } else if (choice.equalsIgnoreCase("R")) {
                        // Reject the transfer
                        boolean success = transferService.rejectTransfer(currentUser.getToken(), transferId);
                        if (success) {
                            System.out.println("Transfer rejected.");
                        } else {
                            System.out.println("Failed to reject the transfer.");
                        }
                    } else {
                        System.out.println("Invalid choice.");
                    }
                }
            } catch(Exception e) {
                    System.out.println("Error retrieving pending transfers. Please try again.");
                    e.printStackTrace();
                }
            } else {
                System.out.println("You need to be logged in to view pending transfers.");
            }
	}

    public void sendBucks() {
        List<User> users = accountService.getUsers(currentUser.getToken());
        consoleService.printUsers(users);

        String recipientUsername = consoleService.promptForString("Enter the username of the recipient: ");
        BigDecimal amount = consoleService.promptForBigDecimal("Enter the amount to send: ");


        int recipientId = accountService.getUserIdByUsername(recipientUsername, currentUser.getToken());
        if (recipientId == currentUser.getUser().getId()) {
            System.out.println("You cannot send money to yourself.");
            return;
        }

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            System.out.println("Amount must be positive.");
            return;
        }

        int senderAccountId = accountService.findAccountIdByUsername(currentUser.getUser().getUsername(), currentUser.getToken());
        BigDecimal senderBalance = accountService.getBalance(currentUser);
        if (amount.compareTo(senderBalance) > 0) {
            System.out.println("Insufficient funds.");
            return;
        }

        int recipientAccountId = accountService.findAccountIdByUsername(recipientUsername, currentUser.getToken());

        boolean debitSuccess = accountService.updateBalance(senderAccountId, senderBalance.subtract(amount), currentUser.getToken());
        if (!debitSuccess) {
            System.out.println("Failed to debit sender's account. Please try again.");
            return;
        }

        //Update the Recipient's Balance
        BigDecimal recipientBalance = accountService.getBalanceByAccountId(recipientAccountId, currentUser.getToken());
        boolean creditSuccess = accountService.updateBalance(recipientAccountId, recipientBalance.add(amount), currentUser.getToken());
        if (!creditSuccess) {
            System.out.println("Failed to credit recipient's account. Please try again.");
            // Ideally, you could add logic to refund the sender in this case to maintain consistency.
            return;
        }

        System.out.println("Transfer successful!");
    }

	private void requestBucks() {
        if (currentUser != null) {
            List<User> users = accountService.getUsers(currentUser.getToken());

            consoleService.printUsers(users);

            String senderUsername = consoleService.promptForString("Enter the username of the person to request from: ");
            int senderId = accountService.getUserIdByUsername(senderUsername, currentUser.getToken());

            if (senderId == currentUser.getUser().getId()) {
                System.out.println("You cannot request money from yourself.");
                return;
            }

            BigDecimal amount = consoleService.promptForBigDecimal("Enter the amount to request: ");
            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                System.out.println("Amount must be positive.");
                return;
            }

            Transfer transfer = new Transfer();
            int recipientAccountId = accountService.findAccountIdByUsername(currentUser.getUser().getUsername(), currentUser.getToken());
            int senderAccountId = accountService.findAccountIdByUsername(senderUsername, currentUser.getToken());

            transfer.setAccountFrom(recipientAccountId);
            transfer.setAccountTo(senderAccountId);
            transfer.setAmount(amount);
            transfer.setTransferStatusId(Transfer.TRANSFER_STATUS_PENDING);
            transfer.setTransferTypeId(Transfer.TRANSFER_TYPE_REQUEST);

            boolean success = transferService.createTransferRequest(currentUser, transfer);
            if (success) {
                System.out.println("Transfer request sent successfully!");
            } else {
                System.out.println("Transfer request failed.");
            }
        } else {
            System.out.println("You need to be logged in to request bucks.");
        }
		
	}

}
