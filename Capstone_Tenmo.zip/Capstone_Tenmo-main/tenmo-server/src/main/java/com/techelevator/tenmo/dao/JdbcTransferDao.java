package com.techelevator.tenmo.dao;

import com.techelevator.tenmo.model.Transfer;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public class JdbcTransferDao implements TransferDao {

    private final JdbcTemplate jdbcTemplate;

    public JdbcTransferDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int getNextTransferId() {
        String sql = "SELECT COALESCE(MAX(transfer_id), 0) + 1 FROM transfer";
        return jdbcTemplate.queryForObject(sql, Integer.class);
    }

    @Override
    public void recordTransfer(int transferId, int transferTypeId, int transferStatusId, int accountFrom, int accountTo, BigDecimal amount) {
        transferId = getNextTransferId();
        String sql = "INSERT INTO transfer (transfer_id, transfer_type_id, transfer_status_id, account_from, account_to, amount) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql, transferId, transferTypeId, transferStatusId, accountFrom, accountTo, amount);
    }

    public List<Transfer> getTransferHistory(int accountId) {
        String sql = "SELECT * FROM transfer WHERE account_from = ? OR account_to = ?";
        return jdbcTemplate.query(sql, new TransferRowMapper(), accountId, accountId);
    }

    public Transfer getTransferById(int transferId) {
        String sql = "SELECT * FROM transfer WHERE transfer_id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new TransferRowMapper(), transferId);
        } catch (EmptyResultDataAccessException e) {
            System.out.println("No transfer found with ID: " + transferId);
            return null;  // Consider returning Optional<Transfer> to handle this properly.
        }
    }

    public List<Transfer> getTransfersByStatus(int accountId, int statusId) {
        String sql = "SELECT * FROM transfer WHERE (account_from = ? OR account_to = ?) AND transfer_status_id = ?";
        return jdbcTemplate.query(sql, new TransferRowMapper(), accountId, accountId, 1);
    }

    public void updateTransferStatus(int transferId, int statusId) {
        String sql = "UPDATE transfer SET transfer_status_id = ? WHERE transfer_id = ?";
        jdbcTemplate.update(sql, statusId, transferId);
    }
}