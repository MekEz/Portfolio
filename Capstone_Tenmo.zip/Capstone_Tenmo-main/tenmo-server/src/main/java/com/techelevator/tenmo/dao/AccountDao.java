package com.techelevator.tenmo.dao;

import java.math.BigDecimal;

public interface AccountDao {
    BigDecimal getBalance(int userId);
    void updateBalance(int userId, BigDecimal newBalance);
    int findIdByUsername(String username);
    int findAccountIdByUsername(String username);

    BigDecimal getBalanceById(int accountId);

    void updateBalanceById(int accountId, BigDecimal newBalance);
}
