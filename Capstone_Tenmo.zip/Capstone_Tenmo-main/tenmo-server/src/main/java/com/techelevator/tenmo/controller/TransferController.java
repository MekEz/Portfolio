package com.techelevator.tenmo.controller;

import com.techelevator.tenmo.dao.AccountDao;
import com.techelevator.tenmo.dao.TransferDao;
import com.techelevator.tenmo.model.Transfer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/transfer")
public class TransferController {

    private final AccountDao accountDao;
    private final TransferDao transferDao;

    @Autowired
    public TransferController(AccountDao accountDao, TransferDao transferDao) {
        this.accountDao = accountDao;
        this.transferDao = transferDao;
    }

    @PostMapping("/send")
    @ResponseStatus(HttpStatus.CREATED)
    public Transfer sendTransfer(@RequestBody Transfer transfer, Authentication authentication) {
        System.out.println("Congratulations, /transfer/send hit successfully.");
        int senderId = accountDao.findIdByUsername(authentication.getName());
        BigDecimal senderBalance = accountDao.getBalance(senderId);

        if (transfer.getAmount().compareTo(senderBalance) > 0) {
            throw new IllegalArgumentException("Insufficient funds.");
        }

        if (transfer.getAccountTo() == 0) {
            throw new IllegalArgumentException("Recipient account ID must be provided.");
        }


        int recipientId = transfer.getAccountTo();
        BigDecimal recipientBalance = accountDao.getBalance(recipientId);
        accountDao.updateBalance(senderId, senderBalance.subtract(transfer.getAmount()));
        accountDao.updateBalance(recipientId, recipientBalance.add(transfer.getAmount()));

        transfer.setTransferStatusId(Transfer.TRANSFER_STATUS_APPROVED);
        transfer.setTransferTypeId(Transfer.TRANSFER_TYPE_SEND);
        //transferDao.recordTransfer(transfer.getTransferId(), transfer.getTransferTypeId(), transfer.getTransferStatusId(), senderId, recipientId, transfer.getAmount());
        return transfer;
    }

    @GetMapping
    public List<Transfer> getTransferHistory(Authentication authentication) {
        int accountId = accountDao.findAccountIdByUsername(authentication.getName());
        return transferDao.getTransferHistory(accountId);
    }

    @GetMapping("/{transferId}")
    public Transfer getTransferById(@PathVariable int transferId, Authentication authentication) {
        return transferDao.getTransferById(transferId);
    }

    @PostMapping("/request")
    @ResponseStatus(HttpStatus.CREATED)
    public void requestTransfer(@RequestBody Transfer transfer, Authentication authentication) {
        transfer.setTransferStatusId(Transfer.TRANSFER_STATUS_PENDING);
        transfer.setTransferTypeId(Transfer.TRANSFER_TYPE_REQUEST);
        transferDao.recordTransfer(transfer.getTransferId(), transfer.getTransferTypeId(), transfer.getTransferStatusId(), transfer.getAccountFrom(), transfer.getAccountTo(), transfer.getAmount());
    }

    @GetMapping("/pending")
    public List<Transfer> getPendingTransfers(Authentication authentication) {
        int accountId = accountDao.findAccountIdByUsername(authentication.getName());
        return transferDao.getTransfersByStatus(accountId, Transfer.TRANSFER_STATUS_PENDING);
    }

    @PutMapping("/approve/{transferId}")
    @ResponseStatus(HttpStatus.OK)
    public void approveTransfer(@PathVariable int transferId, Authentication authentication) {
        Transfer transfer = transferDao.getTransferById(transferId);
        int userId = accountDao.findIdByUsername(authentication.getName());

        if (transfer.getAccountTo() != accountDao.findAccountIdByUsername(authentication.getName())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only approve transfers directed to your account.");
        }

        BigDecimal balance = accountDao.getBalance(userId);
        if (balance.compareTo(transfer.getAmount()) < 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Insufficient funds to approve this transfer.");
        }

        transferDao.updateTransferStatus(transferId, Transfer.TRANSFER_STATUS_APPROVED);
        accountDao.updateBalance(transfer.getAccountFrom(), accountDao.getBalance(transfer.getAccountFrom()).add(transfer.getAmount()));
        accountDao.updateBalance(transfer.getAccountTo(), balance.subtract(transfer.getAmount()));
    }

    @PutMapping("/reject/{transferId}")
    @ResponseStatus(HttpStatus.OK)
    public void rejectTransfer(@PathVariable int transferId, Authentication authentication) {
        Transfer transfer = transferDao.getTransferById(transferId);
        int userId = accountDao.findIdByUsername(authentication.getName());

        if (transfer.getAccountTo() != accountDao.findAccountIdByUsername(authentication.getName())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only reject transfers directed to your account.");
        }

        transferDao.updateTransferStatus(transferId, Transfer.TRANSFER_STATUS_REJECTED);
    }

    @GetMapping("/next-id")
    public int getNextTransferId() {
        return transferDao.getNextTransferId();
    }

    @PutMapping("/new/{transferId}")
    public ResponseEntity<String> updateTransferStatus(@PathVariable int transferId, @RequestBody Transfer transfer) {
        try {
            if (transfer.getTransferId() != transferId) {
                return ResponseEntity.badRequest().body("Transfer ID in path and body do not match.");
            }

            transferDao.updateTransferStatus(transferId, Transfer.TRANSFER_STATUS_APPROVED);
            return ResponseEntity.ok("Transfer status updated successfully.");

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while updating the transfer status.");
        }
    }
}