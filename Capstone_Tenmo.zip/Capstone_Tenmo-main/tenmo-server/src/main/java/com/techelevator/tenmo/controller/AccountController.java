package com.techelevator.tenmo.controller;

import com.techelevator.tenmo.dao.AccountDao;
import com.techelevator.tenmo.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Controller to handle account-related endpoints.
 */
@RestController
@RequestMapping("/account")
public class AccountController {

    private final UserDao userDao;
    private final AccountDao accountDao;

    @Autowired
    public AccountController(UserDao userDao, AccountDao accountDao) {
        this.userDao = userDao;
        this.accountDao = accountDao;
    }

    /**
     * Endpoint to retrieve the authenticated user's account balance.
     */
    @GetMapping("/balance")
    @ResponseStatus(HttpStatus.OK)
    public BigDecimal getAccountBalance(Authentication authentication) {
        // Retrieve the username from authentication and use it to get the user ID
        String username = authentication.getName();
        int userId = userDao.findIdByUsername(username); // Ensure this method exists in UserDao

        return userDao.getAccountBalance(userId);
    }

    @GetMapping("/{username}/id")
    public int getAccountIdByUsername(@PathVariable String username) {
        return accountDao.findAccountIdByUsername(username);
    }

    // Endpoint to get the balance for a specific account by ID
    @GetMapping("/{accountId}/balance")
    public BigDecimal getBalanceByAccountId(@PathVariable int accountId) {
        return accountDao.getBalanceById(accountId);
    }

    // Endpoint to update the balance for a specific account
    @PutMapping("/{accountId}/balance")
    public void updateBalance(@PathVariable int accountId, @RequestBody Map<String, BigDecimal> body) {
        BigDecimal newBalance = body.get("newBalance");
        accountDao.updateBalanceById(accountId, newBalance);
    }


}