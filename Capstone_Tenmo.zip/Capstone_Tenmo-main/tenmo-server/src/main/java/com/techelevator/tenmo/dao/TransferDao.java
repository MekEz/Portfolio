package com.techelevator.tenmo.dao;

import com.techelevator.tenmo.model.Transfer;

import java.math.BigDecimal;
import java.util.List;

public interface TransferDao {
    List<Transfer> getTransferHistory(int userId);

    void recordTransfer(int transferId, int transferTypeId, int transferStatusId, int accountFrom, int accountTo, BigDecimal amount);

    Transfer getTransferById(int transferId);

    List<Transfer> getTransfersByStatus(int accountId, int statusId);

    void updateTransferStatus(int transferId, int statusId);

    int getNextTransferId();
}
