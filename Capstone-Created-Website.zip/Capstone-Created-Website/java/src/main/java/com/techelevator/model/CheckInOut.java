package com.techelevator.model;

import java.time.LocalDateTime;

public class CheckInOut {
    private int visitId;
    private int userId;
    private LocalDateTime checkInTime;
    private LocalDateTime checkOutTime;
    private String visitStatus;

    public int getVisitId() {
        return visitId;
    }

    public void setVisitId(int visitId) {
        this.visitId = visitId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }

    public void setCheckInTime(LocalDateTime checkInTime) {
        this.checkInTime = checkInTime;
    }

    public LocalDateTime getCheckOutTime() {
        return checkOutTime;
    }

    public void setCheckOutTime(LocalDateTime checkOutTime) {
        this.checkOutTime = checkOutTime;
    }

    public String getVisitStatus() {
        return visitStatus;
    }
    public void setVisitStatus(String visitStatus) {
        this.visitStatus = visitStatus;
    }
}
